"""Shared crawler utilities."""

