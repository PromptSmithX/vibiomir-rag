"""Shared crawler utilities."""

